package com.example.Mobile;

import javax.persistence.Entity;
import javax.persistence.Id;


public class Mobile {
	
	Integer id;
	Integer price ;
	Integer speed;
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mobile(int id, int price, Integer speed) {
		super();
		this.id = id;
		this.price = price;
		this.speed = speed;
	}

	@Override
	public String toString() {
		return "Mobile [id=" + id + ", price=" + price + ", speed=" + speed + "]\n";
	}

		
}
	