package com.example.Mobile;

import java.util.ArrayList;
import java.util.TreeSet;

public class SortPhoneTest {

	public static void main(String[] args) {
				
		Mobile m1=new Mobile(1,10,8);
		Mobile m2=new Mobile(4,23, 10);
		Mobile m3=new Mobile(6,23, 25);
		Mobile m4=new Mobile(7,25, 65);
		Mobile m5=new Mobile(8,25, 70);
		Mobile m6=new Mobile(9,10, 10);
		

		ArrayList<Mobile> al=new ArrayList();
		
		al.add(m1);
		al.add(m2);
		al.add(m3);
		al.add(m4);
		al.add(m5);
		al.add(m6);
		
		
		//arrayList.add(12);
		
		System.out.println("Creating TreeSet by adding mobile with price range 15-30");
			
		// TreeSet(Comparator c)
		
		TreeSet<Mobile> treeset=new TreeSet(new SortOnPrice());
		
		for (Mobile mobile : al) 
		{
			int price=mobile.price;
			
			if(price>=15 && price<=30)
				treeset.add(mobile);
		}
				
		System.out.println(treeset);
		
		// add(10,20)
	}
}
