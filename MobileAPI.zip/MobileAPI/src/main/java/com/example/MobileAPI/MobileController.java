package com.example.MobileAPI;


import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:8080")
public class MobileController {
	
	@Autowired
	SessionFactory sf;
	
	List<Mobile> list;
	
	@RequestMapping("getData")
	public List<Mobile> getData()
	{
		//List<Mobile> arrayList =factory.openSession().createCriteria(Mobile.class).list();
		
		List<Mobile> arrayList =sf.openSession().createQuery("from Mobile").list();
		System.out.println(arrayList);

		TreeSet<Mobile> treeset=new TreeSet(new SortOnPrice());
		
		for (Mobile mobile : arrayList) 
		{
			int price=mobile.price;
			
			if(price>=15 && price<=30)
				treeset.add(mobile);
		}
		
		System.out.println(treeset);
		
		ArrayList<Mobile> mobiles=new ArrayList(treeset);
		
		return mobiles ;


	}
	@GetMapping("mobiles")
	List<Mobile> allmobiles()
	{
		Session session=sf.openSession();	
		list=  session.createCriteria(Mobile.class).list();
		return list;
		
	}
	
	//http://localhost:9096/mobile/1
	@GetMapping("mobile/{id}")
	public Mobile getMobileData(@PathVariable int id)
	{
        Session session=sf.openSession();
		Mobile mob=session.load(Mobile.class,id);
		return mob;
	}
	
	@GetMapping("mobilesprice/{price}")
	public Mobile   getMobilePrice(@PathVariable int price)
	{
        Session session=sf.openSession();
		Mobile mob=session.load(Mobile.class,price);
		return mob;
	}
	@PostMapping("mobileadd")
	public List<Mobile> addmobile(@RequestBody Mobile s ) {
           Session session=sf.openSession();
		   Transaction tx = session.beginTransaction();
			session.save(s);
		    tx.commit();
		
		List<Mobile> al=allmobiles();
		
		return al;		 
		
	}
	
	@DeleteMapping("mobiledelete/{rno}")
	public List<Mobile>  deletemobile(@PathVariable int id) {
            Session session=sf.openSession();
		    
            Mobile mobile=session.load(Mobile.class,id);
		    Transaction tx = session.beginTransaction();
			session.delete(mobile);
		    tx.commit();
		    List<Mobile> list=allmobiles();
		    System.err.println( id+" record deleted");
		return list;
	}
	
	
	@PutMapping("mobileupdate")
	public List<Mobile> updatemobile(@RequestBody Mobile clientmobile) {
		Session session=sf.openSession();
		Transaction tx= session.beginTransaction();
		session.saveOrUpdate(clientmobile);
		tx.commit();			
		System.err.println(clientmobile+" record updated successfully");
		return list;
		
	}
	


}
