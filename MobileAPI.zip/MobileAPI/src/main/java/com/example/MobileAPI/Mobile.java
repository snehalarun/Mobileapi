package com.example.MobileAPI;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobile {
	@Id
	Integer id;
	Integer price ;
	Integer speed;
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mobile(int id, int price, Integer speed) {
		super();
		this.id = id;
		this.price = price;
		this.speed = speed;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getSpeed() {
		return speed;
	}

	public void setSpeed(Integer speed) {
		this.speed = speed;
	}

	@Override
	public String toString() {
		return "Mobile [id=" + id + ", price=" + price + ", speed=" + speed + "]\n";
	}

		
}
	