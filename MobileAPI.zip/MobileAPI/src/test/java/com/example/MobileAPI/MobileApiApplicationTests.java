package com.example.MobileAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
