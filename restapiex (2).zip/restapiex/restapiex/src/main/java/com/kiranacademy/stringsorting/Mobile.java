package com.kiranacademy.stringsorting;

public class Mobile 
{

	Integer price; // we will call method using reference price
	Integer speed;
	
	public Mobile(int price, int speed) 
	{
		super();
		this.price = price;
		this.speed = speed;
	}

	@Override
	public String toString() 
	{
		return "Mobile [price=" + price + ", speed=" + speed + "]";
	}
	
	
}
