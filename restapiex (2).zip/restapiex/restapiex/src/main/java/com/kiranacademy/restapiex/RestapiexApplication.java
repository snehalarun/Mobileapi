package com.kiranacademy.restapiex;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

@SpringBootApplication
public class RestapiexApplication {

//	@Autowired
//	DataSource datasource;
//	
	public static void main(String[] args) 
	{
		SpringApplication.run(RestapiexApplication.class, args);
		
	}
	
//	@Bean
//	public LocalSessionFactoryBean getFactory()
//	{
//		LocalSessionFactoryBean factory=new LocalSessionFactoryBean();
//		factory.setDataSource(datasource);
//		factory.setAnnotatedClasses(Student.class);
//		return factory;
//	}

	

}
