package com.kiranacademy.restapiex;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/* 
  To run this API, follow below steps:-
 * 
 * 1) localhost:8080/students - get
 * 2) localhost:8080/student/1  - get
 * 3) localhost:8080/student  - post ( add student object in arraylist )
 * 4) localhost:8080/student/1  - delete 
 * 5) localhost:8080/student - put (update)
 * 
 * 
 *  JSON String format is :-
 *  
 *  {"rno":1,"marks":90}
 *  
 *  */
@RestController
@CrossOrigin("http://localhost:8080")
public class StudentController {
	
	@Autowired
	SessionFactory factory;
	int age;
	
	public void setAge(int a)
	{
		age=a;
	}
	
	// StudentController obj=new StudentController();
	// obj.setAge(10);
	
	public StudentController() {
		
		System.out.println("age is " + age +"factory is " + factory);
		
		//Session session=factory.openSession();
	}
			
	@GetMapping("students")
	List<Student> allStudents()
	{

		Session session=factory.openSession();
		
		List<Student> arrayList= session.createCriteria(Student.class).list();
		
		return arrayList;
		
	}

	
	// @PathVariable assign value of path variable to local variable
	// localhost:8080/student/1
	
	@GetMapping("student/{rno}")
	public Student getStudent(@PathVariable int rno)
	{
		Session session=factory.openSession();
		
		Student student=session.load(Student.class,rno); 
		
		// student==>[rno=1 marks=90 getRno() getMarks()] Student class object
		
		return student; 
		
		// Spring classes will convert above Student class object into JSON String
		// for this Student class must contains public getter methods
		// { "rno" : 1  , "marks" : 90 }
	}
	
	
	// suppose client has sent JSON String { "rno" : 4  , "marks" : 40 }
	// @RequestBody will convert JSON String into Student class object
	
	@PostMapping("student")
	public List<Student>  addStudent(@RequestBody Student student)
	{
		Session session=factory.openSession();
				
		Transaction tx = session.beginTransaction();
		
			session.save(student);
		
		tx.commit();
		
		List<Student> list=allStudents();
		
		return list;		 
		
	}
	
	
	@DeleteMapping("student/{rno}")
	public List<Student> deleteStudent(@PathVariable int rno)
	{
		
		Session session=factory.openSession();
		
		// student is persistent object as it's contents are saved inside database
		
		Student student=session.load(Student.class,rno);
		
		// Student student2=new Student(4,90);
		// student2 is NOT persistent , it is transient object
		
		Transaction tx = session.beginTransaction();
	
			session.delete(student);
			
		tx.commit();
		

		List<Student> list=allStudents();
		
		return list;		 
		
	}
	
	// {"rno":4,"marks":80}
	// clientStudent==>[ rno=4 marks=80 ] Student class object
	
	@PutMapping("student")
	public List<Student> updateStudent(@RequestBody Student clientStudent)
	{

		Session session=factory.openSession();
			
		Transaction tx = session.beginTransaction();
		
			session.saveOrUpdate(clientStudent);
					
		tx.commit();
		

		List<Student> list=allStudents();
		
		return list;		 

	}
	
}
